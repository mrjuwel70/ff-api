Tutorial

Parti 1 : https://youtu.be/JbVSUPz-tnM

Parti 2 : https://youtu.be/2teEOp1BLXU?si=294Jl2tGcZpdwFfo

Source code bot : https://discord.com/invite/qW6e4Ak34y

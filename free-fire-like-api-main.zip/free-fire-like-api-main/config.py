

URLS_LIKE = {"IND":"https://client.ind.freefiremobile.com/LikeProfile",
            "BR":"https://client.us.freefiremobile.com/LikeProfile",
            "US":"https://client.us.freefiremobile.com/LikeProfile",
            "SAC":"https://client.us.freefiremobile.com/LikeProfile",
            "NA":"https://client.us.freefiremobile.com/LikeProfile"}


URLS_INFO = {"IND":"https://client.ind.freefiremobile.com/GetPlayerPersonalShow",
            "BR":"https://client.us.freefiremobile.com/GetPlayerPersonalShow",
            "US":"https://client.us.freefiremobile.com/GetPlayerPersonalShow",
            "SAC":"https://client.us.freefiremobile.com/GetPlayerPersonalShow",
            "NA":"https://client.us.freefiremobile.com/GetPlayerPersonalShow"}



FILES = {"IND":"token_ind.json",
             "BR":"token_br.json",
             "US":"token_br.json",
             "SAC":"token_br.json",
             "NA":"token_br.json"}